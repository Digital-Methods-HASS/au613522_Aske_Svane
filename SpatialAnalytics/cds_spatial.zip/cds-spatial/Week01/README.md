# spatial-analytics
exercises for spatial analytics course, updated as the semester unfolds
